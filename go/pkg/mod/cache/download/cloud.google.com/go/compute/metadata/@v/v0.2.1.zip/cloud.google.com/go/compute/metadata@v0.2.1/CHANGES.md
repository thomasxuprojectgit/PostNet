# Changes

## [0.1.0] (2022-10-26)

Initial release of metadata being it's own module.
