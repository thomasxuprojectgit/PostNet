This package is a fork of github.com/jba/btree at commit
d4edd57f39b8425fc2c631047ff4dc6024d82a4f, which itself was a fork of
github.com/google/btree at 316fb6d3f031ae8f4d457c6c5186b9e3ded70435.

This directory makes the following modifications:

- Updated copyright notice.
- removed LICENSE (it is the same as the repo-wide license, Apache 2.0)
- Removed examples_test.go and .travis.yml.
- Added this file.

