The scripts in this directory are intended to be run by Kokoro CI jobs.
