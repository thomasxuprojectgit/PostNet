#!/bin/bash

XDS_V3_OPT="--xds_v3_support" `dirname $0`/xds.sh
